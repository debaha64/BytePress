# Release Manifest 0.2.0

ID: RELEASE-MANIFEST-0.2.0
Версия: 0.2.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## ID-интервал
- ROAD: `000016...000016`
- PLAN: `000068...000068`

## Журнальный контур
- ReleaseLog: `RL-000007`
- ChangeLog: `CHG-000080`
- QualityLog: `QL-000075`
- Исправление_архива: `CHG-000129`, `QL-000124`

## Включённые ROAD
- `ROAD-000016.md`

## Включённые PLAN
- `PLAN-000068-sync-develop-after-release-0.2.0.md`

## Отсутствующие ожидаемые ROAD
- нет

## Отсутствующие ожидаемые PLAN
- нет

## Проверки
- Создание: `python3 /tmp/bytepress_repack_release_intervals.py`
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.2.0.zip`
- Состав: проверка namelist подтверждает только `MANIFEST.md`, `Backlog/*` и `Plans/*`, без source tree.

## Границы
Zip содержит только manifest, архивные backlog и архивные plan релиза по подтверждённому ID-интервалу. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие owner-documents.
