# Release Manifest 0.2.0

ID: RELEASE-MANIFEST-0.2.0
Версия: 0.2.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## Плановый контур
- ROAD: `ROAD-000016`
- BACK: `BACK-000080`
- PLAN: `PLAN-000068`

## Журнальный контур
- ReleaseLog: `RL-000007`
- ChangeLog: `CHG-000080`
- QualityLog: `QL-000075`
- Исправление_архива: `CHG-000128`, `QL-000123`

## Источник архивных файлов
- Backlog: `Plans/Archive/Backlog/ROAD-000016.md`
- Plan: `Plans/Archive/Plans/PLAN-000068-sync-develop-after-release-0.2.0.md`

## Состав zip
- `MANIFEST.md`
- `Backlog/ROAD-000016.md`
- `Plans/PLAN-000068-sync-develop-after-release-0.2.0.md`

## Проверки
- Создание: `python3 /tmp/bytepress_build_release_archives.py`
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.2.0.zip`
- Состав: `python3 -c <проверка namelist>` подтверждает ровно `MANIFEST.md`, `Backlog/ROAD-000016.md`, `Plans/PLAN-000068-sync-develop-after-release-0.2.0.md` и отсутствие source tree.

## Границы
Zip содержит только manifest, архивный backlog и архивный plan релиза. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие owner-documents.
