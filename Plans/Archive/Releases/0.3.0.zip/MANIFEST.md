# Release Manifest 0.3.0

ID: RELEASE-MANIFEST-0.3.0
Версия: 0.3.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## Плановый контур
- ROAD: `ROAD-000042`
- BACK: `BACK-000107`
- PLAN: `PLAN-000096`

## Журнальный контур
- ReleaseLog: `RL-000009`
- ChangeLog: `CHG-000108`
- QualityLog: `QL-000103`
- Исправление_архива: `CHG-000128`, `QL-000123`

## Источник архивных файлов
- Backlog: `Plans/Archive/Backlog/ROAD-000042.md`
- Plan: `Plans/Archive/Plans/PLAN-000096-post-release-0-3-0-factual-log-and-release-route.md`

## Состав zip
- `MANIFEST.md`
- `Backlog/ROAD-000042.md`
- `Plans/PLAN-000096-post-release-0-3-0-factual-log-and-release-route.md`

## Проверки
- Создание: `python3 /tmp/bytepress_build_release_archives.py`
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.3.0.zip`
- Состав: `python3 -c <проверка namelist>` подтверждает ровно `MANIFEST.md`, `Backlog/ROAD-000042.md`, `Plans/PLAN-000096-post-release-0-3-0-factual-log-and-release-route.md` и отсутствие source tree.

## Границы
Zip содержит только manifest, архивный backlog и архивный plan релиза. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие owner-documents.
