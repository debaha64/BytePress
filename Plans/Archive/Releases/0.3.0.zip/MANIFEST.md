# Release Manifest 0.3.0

ID: RELEASE-MANIFEST-0.3.0
Версия: 0.3.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## ID-интервал
- ROAD: `000017...000042`
- PLAN: `000069...000096`

## Журнальный контур
- ReleaseLog: `RL-000009`
- ChangeLog: `CHG-000108`
- QualityLog: `QL-000103`
- Исправление_архива: `CHG-000129`, `QL-000124`

## Включённые ROAD
- `ROAD-000017.md`
- `ROAD-000018.md`
- `ROAD-000019.md`
- `ROAD-000020.md`
- `ROAD-000021.md`
- `ROAD-000022.md`
- `ROAD-000023.md`
- `ROAD-000024.md`
- `ROAD-000025.md`
- `ROAD-000026.md`
- `ROAD-000027.md`
- `ROAD-000028.md`
- `ROAD-000029.md`
- `ROAD-000030.md`
- `ROAD-000031.md`
- `ROAD-000032.md`
- `ROAD-000033.md`
- `ROAD-000034.md`
- `ROAD-000035.md`
- `ROAD-000036.md`
- `ROAD-000037.md`
- `ROAD-000038.md`
- `ROAD-000039.md`
- `ROAD-000040.md`
- `ROAD-000041.md`
- `ROAD-000042.md`

## Включённые PLAN
- `PLAN-000069-bootstrap-discovery-and-agent-attestation.md`
- `PLAN-000070-close-product-start-control-gaps.md`
- `PLAN-000071-domain-bootstrap-strategy-and-interview-gate.md`
- `PLAN-000072-enforce-branch-gate-and-live-interview.md`
- `PLAN-000073-start-contour-semantic-cleanup.md`
- `PLAN-000074-product-lint-lifecycle-modes.md`
- `PLAN-000075-product-service-update-path.md`
- `PLAN-000076-language-domain-map-cleanup.md`
- `PLAN-000077-domain-maps-and-adrlog-contract.md`
- `PLAN-000078-russian-lint-markers.md`
- `PLAN-000079-profiled-product-factory-domain-model.md`
- `PLAN-000080-profiled-product-tools-bootstrap.md`
- `PLAN-000081-product-skeleton-terms-and-lint.md`
- `PLAN-000082-product-pipeline-domain-cleanup.md`
- `PLAN-000083-created-product-update-route.md`
- `PLAN-000084-system-semantic-cleanup.md`
- `PLAN-000085-verification-contract-cleanup.md`
- `PLAN-000086-product-pipeline-field-test-corrections.md`
- `PLAN-000087-product-pipeline-field-test-fixes.md`
- `PLAN-000088-start-interview-scope-tightening.md`
- `PLAN-000090-pre-release-cleanup-pass.md`
- `PLAN-000091-pre-release-field-test-fixes.md`
- `PLAN-000092-field-test-guardrails.md`
- `PLAN-000093-tools-only-service-entry.md`
- `PLAN-000094-field-test-corrections.md`
- `PLAN-000095-release-readiness-0-3-0.md`
- `PLAN-000096-post-release-0-3-0-factual-log-and-release-route.md`

## Отсутствующие ожидаемые ROAD
- нет

## Отсутствующие ожидаемые PLAN
- `PLAN-000089`

## Проверки
- Создание: `python3 /tmp/bytepress_repack_release_intervals.py`
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.3.0.zip`
- Состав: проверка namelist подтверждает только `MANIFEST.md`, `Backlog/*` и `Plans/*`, без source tree.

## Границы
Zip содержит только manifest, архивные backlog и архивные plan релиза по подтверждённому ID-интервалу. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие owner-documents.
