# Release Manifest 0.1.0

ID: RELEASE-MANIFEST-0.1.0
Версия: 0.1.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## Плановый контур
- ROAD: `ROAD-000015`
- BACK: `BACK-000079`
- PLAN: `PLAN-000067`

## Журнальный контур
- ReleaseLog: `RL-000006`
- ChangeLog: `CHG-000079`
- QualityLog: `QL-000074`
- Исправление_архива: `CHG-000128`, `QL-000123`

## Источник архивных файлов
- Backlog: `Plans/Archive/Backlog/ROAD-000015.md`
- Plan: `Plans/Archive/Plans/PLAN-000067-release-readiness-and-log-closure.md`

## Состав zip
- `MANIFEST.md`
- `Backlog/ROAD-000015.md`
- `Plans/PLAN-000067-release-readiness-and-log-closure.md`

## Проверки
- Создание: `python3 /tmp/bytepress_build_release_archives.py`
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.1.0.zip`
- Состав: `python3 -c <проверка namelist>` подтверждает ровно `MANIFEST.md`, `Backlog/ROAD-000015.md`, `Plans/PLAN-000067-release-readiness-and-log-closure.md` и отсутствие source tree.

## Границы
Zip содержит только manifest, архивный backlog и архивный plan релиза. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие owner-documents.
