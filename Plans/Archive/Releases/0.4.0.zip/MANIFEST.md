# Release Manifest 0.4.0

ID: RELEASE-MANIFEST-0.4.0
Версия: 0.4.0
Статус: Проверено
Дата_создания: 2026-05-24
Дата_изменения: 2026-05-24

## Плановый контур
- ROAD: `ROAD-000043` ... `ROAD-000050`
- BACK: `BACK-000108` ... `BACK-000132`, включая перенесённый `BACK-000115`
- PLAN: `PLAN-000097` ... `PLAN-000122`

## Журнальный контур
- ReleaseLog: `RL-000010`, `RL-000011`
- ChangeLog: `CHG-000108` ... `CHG-000135`
- QualityLog: `QL-000103` ... `QL-000130`

## Git и выпуск
- Release PR: `#137`
- Main commit: `beda664870d84a2d18d3ecd1a11e227a8445847e`
- Tag: `0.4.0`
- Tag type: annotated tag
- GitHub Release: `https://github.com/debaha64/BytePress/releases/tag/0.4.0`

## Источник архивных файлов
- Backlog: `Plans/Archive/Backlog/ROAD-000043.md` ... `ROAD-000050.md`
- Plan: `Plans/Archive/Plans/PLAN-000097-*.md` ... `PLAN-000122-*.md`

## Состав zip
- `MANIFEST.md`
- `Backlog/ROAD-000043.md`
- `Backlog/ROAD-000044.md`
- `Backlog/ROAD-000045.md`
- `Backlog/ROAD-000046.md`
- `Backlog/ROAD-000047.md`
- `Backlog/ROAD-000048.md`
- `Backlog/ROAD-000049.md`
- `Backlog/ROAD-000050.md`
- `Plans/PLAN-000097-restore-strategic-roadmap-0-4-0.md`
- `Plans/PLAN-000098-actualize-backlog-0-4-0.md`
- `Plans/PLAN-000099-planning-contour-rules.md`
- `Plans/PLAN-000100-strengthen-terms-contract.md`
- `Plans/PLAN-000101-term-template-schema-contract.md`
- `Plans/PLAN-000102-bcp14-normative-language.md`
- `Plans/PLAN-000103-opredelenie-gotovnosti.md`
- `Plans/PLAN-000104-managed-agent-pass-protocol.md`
- `Plans/PLAN-000105-managed-pass-semantic-steps.md`
- `Plans/PLAN-000106-push-pr-report-gates.md`
- `Plans/PLAN-000107-verification-levels-and-tool-roles.md`
- `Plans/PLAN-000108-deterministic-check-scope.md`
- `Plans/PLAN-000109-bp-check-implementation-contract.md`
- `Plans/PLAN-000110-minimal-bp-check.md`
- `Plans/PLAN-000111-bp-check-architecture-hardening.md`
- `Plans/PLAN-000112-plans-archive-contour.md`
- `Plans/PLAN-000113-release-manifest-contract.md`
- `Plans/PLAN-000114-release-manifests-0-1-0-0-2-0-0-3-0.md`
- `Plans/PLAN-000115-release-zip-packages.md`
- `Plans/PLAN-000116-release-archive-zip-fix.md`
- `Plans/PLAN-000117-release-archive-id-intervals.md`
- `Plans/PLAN-000118-domain-doc-maps.md`
- `Plans/PLAN-000119-user-layer-normalization.md`
- `Plans/PLAN-000120-horizon-correction.md`
- `Plans/PLAN-000121-record-order.md`
- `Plans/PLAN-000122-release-readiness-0-4-0.md`

## Отсутствующие ожидаемые ID
- отсутствуют

## Проверки
- Создание: `python3` / `zipfile` из текущего дерева post-release прохода.
- Целостность: `python3 -m zipfile -t Plans/Archive/Releases/0.4.0.zip`.
- Состав: namelist zip содержит только `MANIFEST.md`, `Backlog/*`, `Plans/*`.

## Границы
Zip содержит только manifest, архивный backlog и архивный plan релиза. Zip не является текущим источником истины и не заменяет `Logs/ReleaseLog.md`, `Logs/ChangeLog.md`, `Logs/QualityLog.md`, tag или текущие документы-владельцы.
