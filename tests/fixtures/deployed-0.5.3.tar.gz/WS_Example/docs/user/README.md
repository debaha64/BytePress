# Пользовательские задачи Workspace

- [Начальное состояние](first-start.md).
- [После Project Start](after-project-start.md).
- [Режим источника истины](source-of-truth-mode.md).
- [Project Start — Existing Product](existing-product.md).
- [Workspace Update](workspace-update.md).
- [Переход 0.5.1 → 0.5.2](migration-0.5.1-to-0.5.2.md).
- [Подготовка GitHub](github-repository-preparation.md).
- [Обратная связь](feedback.md).

## Как выбрать

Project Start — New Product создаёт новую среду с пустым Product root. Project Start — Existing Product создаёт новую среду с точной копией реального Product root. Workspace Update обновляет Harness существующей среды, сохраняя Product, состояние проекта и историю.

Старый Workspace snapshot, research, logs, отчёты/чаты, .txt, .md, .pdf, .zip или .tar.gz не становятся Existing Product автоматически. Для новой разработки используйте New Product и внешние reference materials первого research; старый Harness/history в Product root не импортируются. Для TAS 0.0.2: New Product, старый TAS 0.0.1 как reference corpus. Project Start запускается из исходной distribution, не из tools этого Workspace.
