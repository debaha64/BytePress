# Первый старт Workspace Example

Project Start завершён. Прочитайте root `README.md`, `AGENTS.md`, `SYSTEM.md`, `Example.profile` и `plans/`. Текущий checkpoint — `WROAD-000001-OWNER-PLANNING`; первый WBACK/WPLAN требует отдельного решения владельца.
New Product создаёт пустой Product root; Existing Product переносит сам Product root. Исторические материалы остаются внешними inputs первого research. [Выбор операции](README.md#как-выбрать) отделяет эти случаи от Workspace Update.
