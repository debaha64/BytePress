# Workspace Example

`WS_Example` — управляемый Workspace продукта `Example`. Project Profile хранит composition, а Product root является самостоятельной delivery boundary.

## Начальное состояние

- `WROAD-000001 active`;
- active WBACK/WPLAN count `0/0`;
- checkpoint `WROAD-000001-OWNER-PLANNING`;
- initial SoT `sot_files`.

Product architecture, первый WBACK/WPLAN, лицензия продукта и переход SoT требуют отдельных решений владельца.

[После Project Start](docs/user/after-project-start.md) поможет выбрать первую задачу. [Документация](docs/README.md) объясняет модель и проверки.

[Обратная связь о продукте](docs/user/feedback.md); записи команды — [Feedback](feedback/README.md).

## Лицензия BytePress Harness

MIT License

Copyright (c) 2026 debaha64

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
