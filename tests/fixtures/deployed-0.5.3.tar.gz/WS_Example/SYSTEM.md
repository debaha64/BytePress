# SYSTEM.md — Workspace Example

## Composition

- root Project Profile: `Example.profile`;
- fixed Product root/delivery boundary: `Example/`;
- deployed Harness version: `0.5.3`;
- configured SoT owner: Project Profile;
- planning authority: root `WROAD -> WBACK -> WPLAN`.

## Feedback

`feedback/` хранит пользовательский опыт по [модели Feedback](docs/technical/feedback.md); `plans/` управляет работой. Feedback не создаёт WBACK/WPLAN автоматически.

## Invariants

1. Workspace управляет работой над Product Unit; Product Unit не хранит текущий Workspace route.
2. В non-executing checkpoint active WPLAN count равен `0`; первая permanent mutation нового прохода создаёт active WPLAN.
3. `sot_files` не читает Git. Product code/checks не исполняются при discovery Profile.
4. Technical PASS, owner acceptance, Product Acceptance и Release Authorization являются разными фактами.
5. Отдельная внешняя операция [Workspace Update](sops/change-management.md#внешняя-граница-workspace-update) из новой distribution действует только над frozen/quiescent Workspace по exact owner authorization; она не открывает ordinary project work или Product mutation без WPLAN.

## Реестр защищённых поверхностей

registry:protected-surfaces

| Path | Protection |
|---|---|
| `Example/**` | `pre-implementation` |
| `AGENTS.md` | `exact-wplan` |
| `SYSTEM.md` | `exact-wplan` |
| `sops/**` | `exact-wplan` |
| `roles/**` | `exact-wplan` |
| `skills/**` | `exact-wplan` |
| `templates/**` | `exact-wplan` |
| `tools/**` | `exact-wplan` |
