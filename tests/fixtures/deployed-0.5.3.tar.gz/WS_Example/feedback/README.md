# Feedback

[Модель](../docs/technical/feedback.md) · [SOP](../sops/feedback.md) · [Как сообщить об опыте](../docs/user/feedback.md).

Индекс содержит только ID, тему и ссылку на запись.

| ID | Тема | Запись |
|---|---|---|
