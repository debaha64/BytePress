# SYSTEM.md — Workspace Example

## Composition

- root Project Profile: `Example.profile`;
- fixed Product root/delivery boundary: `Example/`;
- deployed Harness version: `0.5.2`;
- configured SoT owner: Project Profile;
- planning authority: root `WROAD -> WBACK -> WPLAN`.

## Invariants

1. Workspace управляет работой над Product Unit; Product Unit не хранит текущий Workspace route.
2. В non-executing checkpoint active WPLAN count равен `0`; первая permanent mutation нового прохода создаёт active WPLAN.
3. `sot_files` не читает Git. Product code/checks не исполняются при discovery Profile.
4. Technical PASS, owner acceptance, Product Acceptance и Release Authorization являются разными фактами.
