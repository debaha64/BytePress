# Тесты Workspace

`test_project_profile.py` проверяет развёрнутый контракт Profile; `test_check_workspace.py` — neutral executable SDLC/authority/actual-delta fixtures. Product tests принадлежат Product root и не создаются Project Start.
