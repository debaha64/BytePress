# Терминология Workspace

Будущие изменения ведутся append-only.
