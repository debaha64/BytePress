# Изменения Workspace

- Project Start материализовал `WS_Example` из Harness `0.5.2`.
