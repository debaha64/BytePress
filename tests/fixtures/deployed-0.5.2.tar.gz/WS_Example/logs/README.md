# Журналы Workspace

Типизированные записи ведутся append-only; Project Start не синтезирует owner acceptance.
