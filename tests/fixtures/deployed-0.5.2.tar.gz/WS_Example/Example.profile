{
  "display_name": "Example",
  "harness_version": "0.5.2",
  "schema_version": 1,
  "sot_mode": "sot_files"
}
