# Пользовательские задачи Workspace

- [Начальное состояние](first-start.md).
- [После Project Start](after-project-start.md).
- [Режим источника истины](source-of-truth-mode.md).
- [Существующий продукт](existing-product.md).
- [Обновление Workspace](workspace-update.md).
- [Переход 0.5.1 → 0.5.2](migration-0.5.1-to-0.5.2.md).
- [Подготовка GitHub](github-repository-preparation.md).
