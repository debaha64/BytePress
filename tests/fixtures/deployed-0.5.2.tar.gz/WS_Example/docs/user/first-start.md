# Первый старт Workspace Example

Project Start завершён. Прочитайте root `README.md`, `AGENTS.md`, `SYSTEM.md`, `Example.profile` и `plans/`. Текущий checkpoint — `WROAD-000001-OWNER-PLANNING`; первый WBACK/WPLAN требует отдельного решения владельца.
