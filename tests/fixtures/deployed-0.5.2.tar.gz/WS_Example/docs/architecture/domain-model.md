# Доменная модель Workspace Example

- `Project Profile` — root `Example.profile`, machine owner composition и `sot_mode`.
- `Product Unit` — самостоятельный продукт в fixed Product root `Example/`.
- `WROAD -> WBACK -> WPLAN` — Workspace-owned planning authority.
- `Product Part` — только явно объявленная optional часть; наличие каталога само по себе её не создаёт.

Authorization digest Project Start связывает одну exact materialization, но не является planning authority или owner acceptance.
