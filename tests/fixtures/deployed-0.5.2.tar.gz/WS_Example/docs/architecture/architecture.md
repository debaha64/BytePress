# Архитектура Workspace Example

`WS_Example/` содержит Workspace Harness, root `Example.profile` и единственный Product root `Example/`. Workspace управляет работой, а Product Unit остаётся самостоятельной delivery boundary и не хранит текущий маршрут.

Planning, logs и Workspace research принадлежат root Workspace. Product code, tests, docs и выбранная продуктом лицензия принадлежат Product root.
