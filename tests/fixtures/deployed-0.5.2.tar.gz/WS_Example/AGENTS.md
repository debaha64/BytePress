# AGENTS.md — рабочая карта Workspace Example

Workspace root: `WS_Example`. Product root и delivery boundary: `Example/`.

Единственный machine owner composition и SoT — `Example.profile`; начальный mode — `sot_files`. Git CLI не вызывается до отдельного owner-gated перехода.

Человек управляет, агенты исполняют. Прочитайте `SYSTEM.md`, Project Profile и root `plans/`; technical PASS не является Product Acceptance.
