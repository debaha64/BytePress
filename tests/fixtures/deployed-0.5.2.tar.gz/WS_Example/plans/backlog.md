# Список задач Workspace

| WBACK | WROAD | Статус | Результат | WPLAN | Свидетельство | Контрольная отметка |
|---|---|---|---|---|---|---|

## Текущий маршрут

```text
WROAD-000001 active
active WBACK count 0
active WPLAN count 0
```

NON_EXECUTING_CHECKPOINT: `WROAD-000001-OWNER-PLANNING`.

Список задач хранится в `WS_Example/plans/backlog.md`; плановый контур внутри Product Unit этим шаблоном не создаётся.
