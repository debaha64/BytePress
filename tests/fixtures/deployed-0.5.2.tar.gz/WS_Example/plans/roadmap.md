# Дорожная карта Workspace

| WROAD | Статус | Направление | Следующий крупный переход |
|---|---|---|---|
| WROAD-000001 | active | Neutral reference | Owner planning: определить первый WBACK/WPLAN. |

Дорожная карта хранится в `WS_Example/plans/roadmap.md`, не входит в корень продукта и не содержит исполняемые границы WPLAN.
